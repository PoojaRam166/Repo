-- Create users table with role support
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  role text not null default 'passenger' check (role in ('passenger', 'admin', 'operator')),
  full_name text,
  phone_number text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Enable Row Level Security
alter table public.users enable row level security;

-- RLS Policies
create policy "users_select_own"
  on public.users for select
  using (auth.uid() = id);

create policy "users_insert_own"
  on public.users for insert
  with check (auth.uid() = id);

create policy "users_update_own"
  on public.users for update
  using (auth.uid() = id);

create policy "users_delete_own"
  on public.users for delete
  using (auth.uid() = id);

-- Allow admins to view all users
create policy "admins_select_all"
  on public.users for select
  using (
    auth.uid() in (
      select id from public.users where role = 'admin'
    )
  );
